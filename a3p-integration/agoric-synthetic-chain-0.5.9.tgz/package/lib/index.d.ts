import * as child_process from 'child_process';
import { Options, TemplateExpression } from 'execa';
import * as better_sqlite3 from 'better-sqlite3';
import * as _agoric_cosmic_proto_vstorage_query_js from '@agoric/cosmic-proto/vstorage/query.js';
import * as fs from 'fs';
import * as path from 'path';
import * as fs_promises from 'fs/promises';

declare const makeAgd: ({ execFileSync, }: {
    execFileSync: typeof child_process.execFileSync;
}) => Readonly<{
    readOnly: () => Readonly<{
        status: () => Promise<any>;
        query: (qArgs: [kind: "gov", domain: string, ...rest: any] | [kind: "txs", filter: string] | [kind: "tx", txhash: string] | [mod: "vstorage", kind: "data" | "children", path: string]) => Promise<any>;
    }>;
    nameHub: () => Readonly<{
        /**
         * NOTE: synchronous I/O
         */
        lookup: (...path: string[]) => string;
    }>;
    keys: {
        add: (name: string, mnemonic: string) => string;
    };
    withOpts: (opts: Record<string, unknown>) => Readonly</*elided*/ any>;
    lookup: (...path: string[]) => string;
    status: () => Promise<any>;
    query: (qArgs: [kind: "gov", domain: string, ...rest: any] | [kind: "txs", filter: string] | [kind: "tx", txhash: string] | [mod: "vstorage", kind: "data" | "children", path: string]) => Promise<any>;
    /**
     * @param {string[]} txArgs
     * @param {{ chainId: string, from: string, yes?: boolean }} opts
     */
    tx: (txArgs: string[], { chainId, from, yes, }: {
        chainId: string;
        from: string;
        yes?: boolean;
    }) => Promise<any>;
}>;

declare const BINARY: string;
declare const executeCommand: (command: string, params: string[], options?: Omit<Options, "buffer" | "encoding" | "lines" | "stdio" | "stdout">) => Promise<string>;
declare const agd: {
    query: (...params: string[]) => Promise<any>;
    tx: (...params: string[]) => Promise<any>;
    keys: (...params: string[]) => Promise<any>;
    export: (...params: string[]) => Promise<any>;
};
declare const agoric: {
    follow: (...params: string[]) => Promise<any>;
    wallet: (...params: string[]) => Promise<string>;
    run: (...params: string[]) => Promise<string>;
};
declare const agopsLocation: string;
declare const agops: {
    vaults: (...params: string[]) => Promise<string | string[]>;
    ec: (...params: string[]) => Promise<string>;
    oracle: (...params: string[]) => Promise<string>;
    perf: (...params: string[]) => Promise<string>;
    auctioneer: (...params: string[]) => Promise<string>;
};
declare const bundleSourceLocation: string;
/**
 * @returns Returns the filepath of the bundle
 */
declare const bundleSource: (filePath: string, bundleName: string) => Promise<string>;
declare const wellKnownIdentities: (io?: {}) => Promise<{
    brand: any;
    installation: any;
    instance: any;
}>;
declare const smallCapsContext: () => {
    smallCaps: {
        Nat: (n: number | bigint) => string;
        ref: (obj: any) => any;
    };
    toCapData: (body: unknown) => string;
};

declare const waitForBlock: (n?: number) => Promise<void>;
declare const provisionSmartWallet: (address: string, amount: string) => Promise<void>;
declare const newOfferId: () => Promise<string>;
declare const mkTemp: (template: string) => Promise<string>;
declare const calculateWalletState: (addr: string) => Promise<"old" | "revived" | "upgraded">;
declare const executeOffer: (address: string, offerPromise: string | Promise<string>, options?: Omit<Options, "buffer" | "encoding" | "lines" | "stdio" | "stdout">) => Promise<void>;
declare const getUser: (user: string) => Promise<string>;
/**
 *
 * @param user
 * @returns user address
 */
declare const addUser: (user: string) => Promise<string>;
declare const voteLatestProposalAndWait: (title?: string) => Promise<{
    proposal_id: string;
    voting_end_time: unknown;
    status: string;
}>;
declare const proposalBuilder: (fileName: TemplateExpression) => Promise<{
    evals: {
        permit: string;
        script: string;
    }[];
    bundles: string[];
}>;
declare const installBundle: (addr: string, bundlePath: string) => Promise<void>;
declare const submitProposal: (scriptPath: string, permitPath: string, title: string, description: string) => Promise<void>;

declare const GOV1ADDR: "agoric1ee9hr0jyrxhy999y755mp862ljgycmwyp4pl7q";
declare const GOV2ADDR: "agoric1wrfh296eu2z34p6pah7q04jjuyj3mxu9v98277";
declare const GOV3ADDR: "agoric1ydzxwh6f893jvpaslmaz6l8j2ulup9a7x8qvvq";
declare const USER1ADDR: "agoric1rwwley550k9mmk6uq6mm6z4udrg8kyuyvfszjk";
declare const VALIDATORADDR: "agoric1estsewt6jqsx77pwcxkn5ah0jqgu8rhgflwfdl";
declare const ATOM_DENOM: string;
declare const CHAINID: string;
declare const SDK_ROOT: string;

declare const staticConfig: {
    deposit: string;
    installer: string;
    proposer: string;
    collateralPrice: number;
    swingstorePath: string;
};
type StaticConfig = typeof staticConfig;
type CoreEvalConfig = {
    title?: string;
    description?: string;
};
declare const passCoreEvalProposal: (bundleInfos: BundleInfo[], coreEvalConfig?: CoreEvalConfig) => Promise<void>;
declare const evalBundles: (dir: string) => Promise<void>;

declare const getContractInfo: (path: string, io?: any) => Promise<any>;
/**
 * @param record - e.g. { color: 'blue' }
 * @returns e.g. ['--color', 'blue']
 */
declare const flags: (record: Record<string, string>) => string[];
declare const txAbbr: (tx: any) => {
    txhash: any;
    codespace: any;
    code: any;
    height: any;
    gas_used: any;
};
declare const loadedBundleIds: (swingstore: any) => any;
/**
 * @param cacheFn - e.g. /home/me.agoric/cache/b1-DEADBEEF.json
 */
declare const bundleDetail: (cacheFn: string) => {
    fileName: string;
    endoZipBase64Sha512: string;
    id: string;
};
type BundleInfo = {
    name: string;
    dir: string;
    bundles: string[];
    evals: {
        permit: string;
        script: string;
    }[];
};
declare const ensureISTForInstall: (agd: ReturnType<typeof makeAgd>, config: StaticConfig, bytes: number, { log }: {
    log: (...args: any[]) => void;
}) => Promise<void>;
declare const readBundles: (dir: string) => Promise<BundleInfo[]>;

declare function openVault(address: string, mint: string, collateral: string): Promise<void>;
declare function adjustVault(address: any, vaultId: any, vaultParams: any): Promise<void>;
declare function closeVault(address: any, vaultId: any, mint: any): Promise<void>;
declare function mintIST(addr: any, sendValue: any, wantMinted: any, giveCollateral: any): Promise<void>;
declare function getISTBalance(addr: any, denom?: string, unit?: number): Promise<number>;
declare function checkForOracle(t: any, name: any): Promise<void>;
declare function registerOraclesForBrand(brandIn: any, oraclesByBrand: any): Promise<void[]>;
declare function addPreexistingOracles(brandIn: any, oraclesByBrand: any): Promise<void>;
declare function generateOracleMap(baseId: string, brandNames: string[]): Map<any, any>;
declare function pushPrices(price: any, brandIn: any, oraclesByBrand: any, round: any): Promise<void>;
declare function getRoundId(price: any, io?: {}): Promise<number>;
declare function getPriceQuote(price: any): Promise<any>;
declare function agopsInter(...params: any[]): Promise<string>;
declare function createBid(price: any, addr: any, offerId: any): Promise<string>;
declare function getLiveOffers(addr: any): Promise<any>;
declare function getAuctionCollateral(index: any): Promise<any>;
declare function getVaultPrices(index: any): Promise<any>;
declare function getProvisionPoolMetrics(): Promise<any>;

declare const step: (name: string, fn: Function) => Promise<void>;

declare const HOME: string;
declare function dbTool(db: better_sqlite3.Database): {
    (strings: any, ...args: any[]): unknown[];
    get(strings: any, ...args: any[]): unknown;
};
declare function getVatDetails(vatName: string): Promise<{
    vatName: string;
    vatID: string;
    incarnation: number;
    terminated: boolean;
}>;
declare function getIncarnation(vatName: string): Promise<number>;
declare function getDetailsMatchingVats(vatSubstring: string): Promise<{
    vatName: string;
    vatID: string;
    incarnation: number;
    terminated: boolean;
}[]>;
type SwingstoreTool = ReturnType<typeof makeSwingstoreTool>;
/** @param {import('better-sqlite3').Database} db */
declare function makeSwingstoreTool(db: better_sqlite3.Database): Readonly<{
    /**
     * Return the vatID for a vat whose name includes the provided string, or an
     * error if there is no such vat. If multiple vats match, the return value
     * prefers static vats over dynamic vats but makes no other guarantees.
     *
     * @param {string} vatName
     */
    findVat: (vatName: string) => any;
    /**
     * Return an array of vatIDs for which the vat name includes the provided string.
     *
     * @param {string} vatName
     */
    findVats: (vatName: string) => any[];
    lookupVat: (vatID: string) => Readonly<{
        source: () => any;
        options: () => any;
        currentSpan: () => unknown;
        terminated: () => any;
    }>;
}>;

declare function extractStreamCellValue(data: _agoric_cosmic_proto_vstorage_query_js.QueryDataResponse, index?: number): unknown;
declare function queryVstorage(path: string): Promise<any>;
declare function getQuoteBody(path: string): Promise<any>;
declare function getInstanceBoardId(instanceName: string): Promise<string | null>;

declare function makeWebRd(root: string, { fetch, log }: {
    fetch: typeof globalThis.fetch;
    log?: ((...msgs: any[]) => void) | undefined;
}): {
    toString: () => string;
    /** @param {string[]} segments */
    join: (...segments: string[]) => /*elided*/ any;
    readText: () => Promise<string>;
    readJSON: () => Promise<any>;
};
declare function makeFileRd(root: string, { fsp, path }: {
    fsp: Pick<typeof fs_promises, "stat" | "readFile">;
    path: Pick<typeof path, "join">;
}): {
    toString: () => string;
    /** @param {string[]} segments */
    join: (...segments: string[]) => /*elided*/ any;
    stat: () => Promise<fs.Stats>;
    readText: () => Promise<string>;
    readJSON: () => Promise<any>;
};
declare function makeDirRd(root: string, { fsp, fs, path }: {
    fsp: Pick<typeof fs_promises, "stat" | "readFile">;
    fs: Pick<typeof fs, "readdir" | "existsSync">;
    path: Pick<typeof path, "join" | "basename">;
}): {
    toString: () => string;
    /** @param {string[]} segments */
    join: (...segments: string[]) => /*elided*/ any;
    /** @param {string} [suffix] */
    basename: (suffix?: string) => string;
    asFileRd: () => {
        toString: () => string;
        /** @param {string[]} segments */
        join: (...segments: string[]) => /*elided*/ any;
        stat: () => Promise<fs.Stats>;
        readText: () => Promise<string>;
        readJSON: () => Promise<any>;
    };
    existsSync: () => boolean;
    /** @returns {Promise<DirRd[]>} */
    readdir: () => Promise<DirRd[]>;
};
declare function makeFileRW(root: string, { fsp, path }: {
    fsp: Pick<typeof fs_promises, "stat" | "readFile" | "writeFile" | "unlink" | "mkdir" | "rmdir">;
    path: Pick<typeof path, "join">;
}): {
    toString: () => string;
    readOnly: () => {
        toString: () => string;
        /** @param {string[]} segments */
        join: (...segments: string[]) => /*elided*/ any;
        stat: () => Promise<fs.Stats>;
        readText: () => Promise<string>;
        readJSON: () => Promise<any>;
    };
    /** @param {string[]} segments */
    join: (...segments: string[]) => /*elided*/ any;
    writeText: (text: any) => Promise<void>;
    unlink: () => Promise<void>;
    mkdir: () => Promise<string | undefined>;
    rmdir: () => Promise<void>;
};
declare function makeDirRW(root: string, { fsp, fs, path }: {
    fsp: Pick<typeof fs_promises, "stat" | "readFile" | "writeFile" | "unlink" | "mkdir" | "rmdir" | "open">;
    fs: Pick<typeof fs, "readdir" | "existsSync">;
    path: Pick<typeof path, "join" | "basename">;
}): {
    toString: () => string;
    readOnly: () => {
        toString: () => string;
        /** @param {string[]} segments */
        join: (...segments: string[]) => /*elided*/ any;
        /** @param {string} [suffix] */
        basename: (suffix?: string) => string;
        asFileRd: () => {
            toString: () => string;
            /** @param {string[]} segments */
            join: (...segments: string[]) => /*elided*/ any;
            stat: () => Promise<fs.Stats>;
            readText: () => Promise<string>;
            readJSON: () => Promise<any>;
        };
        existsSync: () => boolean;
        /** @returns {Promise<DirRd[]>} */
        readdir: () => Promise<DirRd[]>;
    };
    asFileRW: () => {
        toString: () => string;
        readOnly: () => {
            toString: () => string;
            /** @param {string[]} segments */
            join: (...segments: string[]) => /*elided*/ any;
            stat: () => Promise<fs.Stats>;
            readText: () => Promise<string>;
            readJSON: () => Promise<any>;
        };
        /** @param {string[]} segments */
        join: (...segments: string[]) => /*elided*/ any;
        writeText: (text: any) => Promise<void>;
        unlink: () => Promise<void>;
        mkdir: () => Promise<string | undefined>;
        rmdir: () => Promise<void>;
    };
    mkdir: () => Promise<void>;
    rmdir: () => Promise<void>;
    /** @param {string[]} segments */
    join: (...segments: string[]) => /*elided*/ any;
    touch: () => Promise<void>;
};
declare function makeWebCache(src: TextRd, dest: FileRW): {
    toString: () => string;
    /** @param {string} segment */
    getText: (segment: string) => Promise<string>;
    /** @param {string} segment */
    storedPath: (segment: string) => Promise<string>;
    /** @param {string} segment */
    size: (segment: string) => Promise<number>;
    remove: () => Promise<void>;
};
type TextRd = ReturnType<typeof makeWebRd>;
/**
 * Reify file read access as an object.
 */
type FileRd = ReturnType<typeof makeFileRd>;
/**
 * Reify file read access as an object.
 */
type DirRd = ReturnType<typeof makeDirRd>;
/**
 * Reify file read/write access as an object.
 */
type FileRW = ReturnType<typeof makeFileRW>;
/**
 * Reify file read/write access as an object.
 */
type DirRW = ReturnType<typeof makeDirRW>;
type WebCache = ReturnType<typeof makeWebCache>;

export { ATOM_DENOM, BINARY, type BundleInfo, CHAINID, type CoreEvalConfig, type DirRW, type DirRd, type FileRW, type FileRd, GOV1ADDR, GOV2ADDR, GOV3ADDR, HOME, SDK_ROOT, type StaticConfig, type SwingstoreTool, type TextRd, USER1ADDR, VALIDATORADDR, type WebCache, addPreexistingOracles, addUser, adjustVault, agd, agops, agopsInter, agopsLocation, agoric, bundleDetail, bundleSource, bundleSourceLocation, calculateWalletState, checkForOracle, closeVault, createBid, dbTool, ensureISTForInstall, evalBundles, executeCommand, executeOffer, extractStreamCellValue, flags, generateOracleMap, getAuctionCollateral, getContractInfo, getDetailsMatchingVats, getISTBalance, getIncarnation, getInstanceBoardId, getLiveOffers, getPriceQuote, getProvisionPoolMetrics, getQuoteBody, getRoundId, getUser, getVatDetails, getVaultPrices, installBundle, loadedBundleIds, makeAgd, makeDirRW, makeDirRd, makeFileRW, makeFileRd, makeWebCache, makeWebRd, mintIST, mkTemp, newOfferId, openVault, passCoreEvalProposal, proposalBuilder, provisionSmartWallet, pushPrices, queryVstorage, readBundles, registerOraclesForBrand, smallCapsContext, staticConfig, step, submitProposal, txAbbr, voteLatestProposalAndWait, waitForBlock, wellKnownIdentities };

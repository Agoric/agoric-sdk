#!/usr/bin/env -S node --import ts-blank-space/register

// src/cli/cli.ts
import chalk from "chalk";
import assert3 from "assert";
import { execSync as execSync3 } from "child_process";
import path4 from "path";
import { parseArgs } from "util";

// src/cli/build.ts
import { execSync } from "child_process";
import fs from "fs";
import path from "path";
var defaultConfig = {
  // Tag of the agoric-3 image containing all passed proposals
  // Must match the Bake file and CI config
  fromTag: "latest"
};
function readBuildConfig(root2) {
  const packageJsonPath = path.join(root2, "package.json");
  const packageJson = fs.readFileSync(packageJsonPath, "utf-8");
  const { agoricSyntheticChain } = JSON.parse(packageJson);
  const config = { ...defaultConfig, ...agoricSyntheticChain };
  return config;
}
var buildProposalSubmissions = (proposals2) => {
  for (const proposal of proposals2) {
    if (!("source" in proposal && proposal.source === "build")) continue;
    console.log(
      "Refreshing submission for",
      proposal.proposalIdentifier,
      proposal.proposalName
    );
    const { buildScript } = proposal;
    const proposalPath = `proposals/${path}`;
    const submissionPath = `${proposalPath}/submission`;
    const relativeBuildScript = path.relative(submissionPath, buildScript);
    execSync(`mkdir -p ${submissionPath}`);
    execSync(`agoric run ${relativeBuildScript}`, {
      cwd: submissionPath,
      env: { ...process.env, HOME: "." }
    });
    const planPath = execSync(
      `find ${submissionPath} -maxdepth 1 -type f -name '*-plan.json'`
    ).toString().trim();
    const plan = JSON.parse(fs.readFileSync(planPath, "utf-8"));
    for (const { fileName } of plan.bundles) {
      execSync(`cp ${fileName} ${submissionPath}`);
      execSync(`touch -t 197001010000 ${submissionPath}/${fileName}`);
    }
  }
};
var bakeTarget = (target, dry = false) => {
  const cmd2 = [
    "docker",
    "buildx",
    "bake",
    `--load "${target}"`,
    dry && "--print",
    process.env.DOCKER_PROGRESS_FORMAT && `--progress "${process.env.DOCKER_PROGRESS_FORMAT}"`
  ].filter(Boolean).join(" ");
  console.log(cmd2);
  execSync(cmd2, { stdio: "inherit" });
};

// src/cli/dockerfileGen.ts
import fs3 from "fs";

// src/cli/proposals.ts
import assert from "assert";
import fs2 from "fs";
import * as path2 from "path";
var repository = "ghcr.io/agoric/agoric-3-proposals";
function readInfo(proposalPath) {
  assert(
    proposalPath === proposalPath.toLowerCase(),
    // because they go in Dockerfile target names
    "proposal directories must be lowercase"
  );
  const packageJsonPath = path2.join("proposals", proposalPath, "package.json");
  const packageJson = fs2.readFileSync(packageJsonPath, "utf-8");
  const { agoricProposal } = JSON.parse(packageJson);
  assert(agoricProposal, "missing agoricProposal in package.json");
  const [proposalIdentifier, proposalName] = proposalPath.split(":");
  return {
    ...agoricProposal,
    path: proposalPath,
    proposalIdentifier,
    proposalName
  };
}
function encodeUpgradeInfo(upgradeInfo) {
  return upgradeInfo != null ? JSON.stringify(upgradeInfo) : "";
}
function compareProposalDirNames(a, b) {
  const [_a, aPos, aNumericPos] = a.match(/^(([0-9]+)|[^:]*):.*/) || [];
  const [_b, bPos, bNumericPos] = b.match(/^(([0-9]+)|[^:]*):.*/) || [];
  if (aNumericPos && !bNumericPos) return -1;
  if (!aNumericPos && bNumericPos) return 1;
  if (aNumericPos && bNumericPos) {
    if (Number(aNumericPos) < Number(bNumericPos)) return -1;
    if (Number(aNumericPos) > Number(bNumericPos)) return 1;
  }
  if (aPos !== void 0 && bPos === void 0) return -1;
  if (aPos === void 0 && bPos !== void 0) return 1;
  if (aPos !== void 0 && bPos !== void 0) {
    if (aPos < bPos) return -1;
    if (aPos > bPos) return 1;
  }
  return a < b ? -1 : a > b ? 1 : 0;
}
function readProposals(proposalsParent) {
  const proposalsDir = path2.join(proposalsParent, "proposals");
  const proposalPaths = fs2.readdirSync(proposalsDir, { withFileTypes: true }).filter((dirent) => {
    assert("path" in dirent, "missing path in dirent added in Node 18.17");
    const hasPackageJson = fs2.existsSync(
      path2.join(dirent.path, dirent.name, "package.json")
    );
    if (!hasPackageJson) {
      console.warn(
        "WARN ignoring non-package in proposal directory:",
        dirent.name
      );
    }
    return hasPackageJson;
  }).map((dirent) => dirent.name).sort(compareProposalDirNames);
  return proposalPaths.map(readInfo);
}
function imageNameForProposal(proposal, stage2) {
  const target = `${stage2}-${proposal.proposalName}`;
  return {
    name: `${repository}:${target}`,
    target
  };
}
function isPassed(proposal) {
  return proposal.proposalIdentifier.match(/^\d/);
}

// src/cli/dockerfileGen.ts
var syntaxPragma = "# syntax=docker/dockerfile:1.7-labs";
var stage = {
  /**
   * Prepare an upgrade from ag0, start of the chain
   */
  PREPARE_ZERO(proposalName, to) {
    const agZeroUpgrade = "agoric-upgrade-7-2";
    return `
## START
# on ${agZeroUpgrade}, with upgrade to ${to}
FROM ghcr.io/agoric/ag0:${agZeroUpgrade} as prepare-${proposalName}
ENV UPGRADE_TO=${to}

# put env functions into shell environment
RUN echo '. /usr/src/upgrade-test-scripts/env_setup.sh' >> ~/.bashrc

# copy scripts
${createCopyCommand(
      [],
      "./upgrade-test-scripts/env_setup.sh",
      "./upgrade-test-scripts/run_prepare_zero.sh",
      "/usr/src/upgrade-test-scripts/"
    )}
SHELL ["/bin/bash", "-c"]
# this is the only layer that starts ag0
RUN /usr/src/upgrade-test-scripts/run_prepare_zero.sh
`;
  },
  /**
   * Resume from state of an existing image.
   * Creates a "use" stage upon which a PREPARE or EVAL can stack.
   */
  RESUME(fromTag) {
    return `
## RESUME
FROM ghcr.io/agoric/agoric-3-proposals:${fromTag} as use-${fromTag}
`;
  },
  /**
   * Prepare an upgrade handler to run.
   *
   * - Submit the software-upgrade proposal for planName and run until upgradeHeight, leaving the state-dir ready for next agd.
   */
  PREPARE({
    path: path5,
    planName,
    proposalName,
    upgradeInfo,
    releaseNotes
  }, lastProposal) {
    const skipProposalValidation = !releaseNotes;
    return `
# PREPARE ${proposalName}

# upgrading to ${planName}
FROM use-${lastProposal.proposalName} as prepare-${proposalName}
ENV     UPGRADE_TO=${planName}     UPGRADE_INFO=${JSON.stringify(encodeUpgradeInfo(upgradeInfo))}     SKIP_PROPOSAL_VALIDATION=${skipProposalValidation}

${createCopyCommand(
      ["host", "node_modules", "test", "test.sh"],
      `./proposals/${path5}`,
      `/usr/src/proposals/${path5}`
    )}
${createCopyCommand(
      [],
      "./upgrade-test-scripts/env_setup.sh",
      "./upgrade-test-scripts/run_prepare.sh",
      "./upgrade-test-scripts/start_to_to.sh",
      "/usr/src/upgrade-test-scripts/"
    )}
WORKDIR /usr/src/upgrade-test-scripts
SHELL ["/bin/bash", "-c"]
RUN ./run_prepare.sh ${path5}
`;
  },
  /**
   * Execute a prepared upgrade.
   * - Start agd with the SDK that has the upgradeHandler
   * - Run any core-evals associated with the proposal (either the ones specified in prepare, or straight from the proposal)
   */
  EXECUTE({
    path: path5,
    planName,
    proposalName,
    sdkImageTag
  }) {
    return `
# EXECUTE ${proposalName}
FROM ghcr.io/agoric/agoric-sdk:${sdkImageTag} as execute-${proposalName}

WORKDIR /usr/src/upgrade-test-scripts

# base is a fresh sdk image so set up the proposal and its dependencies
${createCopyCommand(
      ["host", "node_modules", "test", "test.sh"],
      `./proposals/${path5}`,
      `/usr/src/proposals/${path5}`
    )}
${createCopyCommand(
      [],
      "./upgrade-test-scripts/env_setup.sh",
      "./upgrade-test-scripts/run_execute.sh",
      "./upgrade-test-scripts/start_to_to.sh",
      "./upgrade-test-scripts/install_deps.sh",
      "/usr/src/upgrade-test-scripts/"
    )}
RUN --mount=type=cache,target=/root/.yarn ./install_deps.sh ${path5}

COPY --link --from=prepare-${proposalName} /root/.agoric /root/.agoric

SHELL ["/bin/bash", "-c"]
RUN ./run_execute.sh ${planName}
`;
  },
  /**
   * Run a core-eval proposal
   * - Run the core-eval scripts from the proposal. They are only guaranteed to have started, not completed.
   */
  EVAL({ path: path5, proposalName }, lastProposal) {
    return `
# EVAL ${proposalName}
FROM use-${lastProposal.proposalName} as eval-${proposalName}

${createCopyCommand(
      ["host", "node_modules", "test", "test.sh"],
      `./proposals/${path5}`,
      `/usr/src/proposals/${path5}`
    )}

WORKDIR /usr/src/upgrade-test-scripts

# First stage of this proposal so install its deps.
${createCopyCommand(
      [],
      "./upgrade-test-scripts/install_deps.sh",
      "/usr/src/upgrade-test-scripts/"
    )}
RUN --mount=type=cache,target=/root/.yarn ./install_deps.sh ${path5}

${createCopyCommand(
      [],
      "./upgrade-test-scripts/*eval*",
      "/usr/src/upgrade-test-scripts/"
    )}
SHELL ["/bin/bash", "-c"]
RUN ./run_eval.sh ${path5}
`;
  },
  /**
   * Use the proposal
   *
   * - Perform any mutations that should be part of chain history
   */
  USE({ path: path5, proposalName, type }) {
    const previousStage = type === "Software Upgrade Proposal" ? "execute" : "eval";
    return `
# USE ${proposalName}
FROM ${previousStage}-${proposalName} as use-${proposalName}

WORKDIR /usr/src/upgrade-test-scripts

${createCopyCommand(
      [],
      "./upgrade-test-scripts/run_use.sh",
      "./upgrade-test-scripts/start_agd.sh",
      "/usr/src/upgrade-test-scripts/"
    )}
SHELL ["/bin/bash", "-c"]
RUN ./run_use.sh ${path5}
ENTRYPOINT ./start_agd.sh
`;
  },
  /**
   * Generate image than can test the proposal
   *
   * - Run with the image of the last "use"
   * - Run tests of the proposal
   *
   * Needs to be an image to have access to the SwingSet db. run it with `docker run --rm` to not make the container ephemeral.
   */
  TEST({ path: path5, proposalName }) {
    return `
# TEST ${proposalName}
FROM use-${proposalName} as test-${proposalName}

# Previous stages copied excluding test files (see COPY above). It would be good
# to copy only missing files, but there may be none. Fortunately, copying extra
# does not invalidate other images because nothing depends on this layer.
${createCopyCommand(
      ["host", "node_modules"],
      `./proposals/${path5}`,
      `/usr/src/proposals/${path5}`
    )}

WORKDIR /usr/src/upgrade-test-scripts

${createCopyCommand(
      [],
      "./upgrade-test-scripts/run_test.sh",
      "/usr/src/upgrade-test-scripts/"
    )}
SHELL ["/bin/bash", "-c"]
ENTRYPOINT ./run_test.sh ${path5}
`;
  },
  /**
   * The last target in the file, for untargeted `docker build`
   */
  LAST(lastProposal) {
    const useImage = imageNameForProposal(lastProposal, "use").name;
    return `
# LAST
FROM ${useImage} as latest
`;
  }
};
var createCopyCommand = (exclusionList, ...files) => [
  "COPY",
  "--link",
  "--chmod=755",
  ...exclusionList.map((excluded) => `--exclude=${excluded}`),
  ...files
].join(" ");
function writeBakefileProposals(allProposals2, platforms) {
  const json = {
    variable: {
      PLATFORMS: {
        default: platforms || null
      },
      PROPOSALS: {
        default: allProposals2.map((p) => p.proposalName)
      }
    }
  };
  fs3.writeFileSync("docker-bake.json", JSON.stringify(json, null, 2));
}
function writeDockerfile(allProposals2, fromTag) {
  const blocks = [syntaxPragma];
  let previousProposal = null;
  if (fromTag) {
    blocks.push(stage.RESUME(fromTag));
    previousProposal = {
      proposalName: fromTag,
      proposalIdentifier: fromTag,
      // XXX these are bogus
      path: ".",
      type: "/agoric.swingset.CoreEvalProposal",
      source: "subdir"
    };
  }
  for (const proposal of allProposals2) {
    blocks.push(
      `#----------------
# ${proposal.proposalName}
#----------------`
    );
    switch (proposal.type) {
      case "/agoric.swingset.CoreEvalProposal":
      case "/cosmos.params.v1beta1.ParameterChangeProposal":
        blocks.push(stage.EVAL(proposal, previousProposal));
        break;
      case "Software Upgrade Proposal":
        if (previousProposal) {
          blocks.push(stage.PREPARE(proposal, previousProposal));
        } else {
          blocks.push(
            stage.PREPARE_ZERO(proposal.proposalName, proposal.planName)
          );
        }
        blocks.push(stage.EXECUTE(proposal));
        break;
      default:
        throw new Error(`unsupported proposal type ${proposal.type}`);
    }
    blocks.push(stage.USE(proposal));
    blocks.push(stage.TEST(proposal));
    previousProposal = proposal;
  }
  const lastPassed = allProposals2.findLast(isPassed);
  if (lastPassed) {
    blocks.push(stage.LAST(lastPassed));
  }
  const contents = blocks.join("\n");
  fs3.writeFileSync("Dockerfile", contents);
}

// src/cli/doctor.ts
import fs4 from "fs";
import path3 from "path";
import { glob } from "glob";
import assert2 from "assert";
import { execSync as execSync2 } from "child_process";
var checkShellScripts = (proposalPath) => {
  const shellScripts = glob.sync("*.sh", { cwd: proposalPath });
  for (const script of shellScripts) {
    const scriptPath = path3.join(proposalPath, script);
    const content = fs4.readFileSync(scriptPath, "utf-8");
    assert2(
      content.includes("set -e"),
      `${script} must include "set -e"; otherwise lines may fail silently. "set -euo pipefail" is recommended.`
    );
  }
};
var fixupProposal = (proposal) => {
  const proposalPath = path3.join("proposals", proposal.path);
  checkShellScripts(proposalPath);
  const packageJson = JSON.parse(
    fs4.readFileSync(path3.join(proposalPath, "package.json"), "utf-8")
  );
  if (packageJson.dependencies || packageJson.devDependencies) {
    assert2(
      packageJson.packageManager,
      "missing packageManager in package.json"
    );
    if (packageJson.packageManager.includes("yarn")) {
      console.log('found "yarn" packageManager, processing...');
      const yarnLock = path3.join(proposalPath, "yarn.lock");
      if (!fs4.existsSync(yarnLock)) {
        console.log(`creating empty ${yarnLock}`);
        fs4.writeFileSync(yarnLock, "");
      }
      const yarnRc = path3.join(proposalPath, ".yarnrc.yml");
      if (!fs4.existsSync(yarnRc)) {
        console.log(`creating ${yarnRc} with node-modules linker`);
        fs4.writeFileSync(yarnRc, "nodeLinker: node-modules\n");
      }
      execSync2("rm -rf node_modules", { cwd: proposalPath });
      execSync2("yarn install --mode=skip-build", { cwd: proposalPath });
    }
  }
};
var checkYarn = () => {
  const yarnpath = execSync2("which yarn", {
    encoding: "utf-8"
  });
  console.log(yarnpath);
  if (yarnpath.includes("homebrew")) {
    console.error(
      "Homebrew installs of yarn are not supported. Use corepack instead:"
    );
    console.error("  brew uninstall yarn");
    process.exit(1);
  }
  const packageJson = JSON.parse(
    fs4.readFileSync(path3.join("package.json"), "utf-8")
  );
  const expectedYarnVersion = packageJson.packageManager.match(/yarn@(\d+\.\d+\.\d+)/)[1];
  const actualYarnVersion = execSync2("yarn --version", {
    encoding: "utf-8"
  }).trim();
  if (actualYarnVersion !== expectedYarnVersion) {
    console.log({ actualYarnVersion, expectedYarnVersion });
    console.error(
      `Corepack specifies yarn version ${expectedYarnVersion} but the path has ${actualYarnVersion}`
    );
    console.error("Find a way to remove the global yarn before proceeding.");
    process.exit(1);
  }
};
var runDoctor = (proposals2) => {
  console.log("Running doctor...");
  console.log("enabling corepack");
  execSync2("corepack enable", { stdio: "inherit" });
  checkYarn();
  console.log("Verifying the CLI runs and create the Dockerfiles");
  execSync2("yarn synthetic-chain prepare-build", { stdio: "inherit" });
  console.log(
    "Verifying the install Docker Buildx is new enough to handle the Bake file"
  );
  try {
    execSync2("docker buildx bake --print");
  } catch (e) {
    console.error("Docker Buildx version is too old");
    execSync2("docker buildx version", { stdio: "inherit" });
    console.log(
      "It must be at least 0.11. https://docs.docker.com/build/release-notes/#0110"
    );
    process.exit(1);
  }
  for (const proposal of proposals2) {
    try {
      console.log("\nchecking proposal", proposal.proposalName, "...");
      fixupProposal(proposal);
      console.log("passed");
    } catch (e) {
      console.error("message" in e ? e.message : e);
      console.log("PROBLEM ^^^  After correcting, run doctor again.");
    }
  }
};

// src/cli/run.ts
import { spawnSync } from "child_process";
import { existsSync, realpathSync } from "fs";
import { resolve as resolvePath } from "path";
import { fileSync as createTempFile } from "tmp";
var createMessageFile = (proposal) => createTempFile({ prefix: proposal.proposalName });
var executeHostScriptIfPresent = (extraEnv, proposal, scriptName) => {
  const scriptPath = `${resolvePath(".")}/proposals/${proposal.path}/host/${scriptName}`;
  if (existsSync(scriptPath)) {
    console.log(
      `Running script ${scriptName} for proposal ${proposal.proposalName}`
    );
    spawnSync(scriptPath, {
      env: { ...process.env, ...extraEnv },
      stdio: "inherit"
    });
  }
};
var propagateSlogfile = (env) => {
  const { SLOGFILE } = env;
  if (!SLOGFILE) return [];
  spawnSync("touch", [SLOGFILE]);
  return [
    "--env",
    `SLOGFILE=${SLOGFILE}`,
    "--volume",
    `${SLOGFILE}:${realpathSync(SLOGFILE)}`
  ];
};
var runTestImage = ({
  extraDockerArgs = [],
  proposal,
  removeContainerOnExit = true
}) => {
  const { name: messageFilePath, removeCallback: removeTempFileCallback } = createMessageFile(proposal);
  const containerFilePath = "/root/message-file-path";
  const { name: imageName } = imageNameForProposal(proposal, "test");
  let runResult;
  try {
    executeHostScriptIfPresent(
      {
        MESSAGE_FILE_PATH: messageFilePath
      },
      proposal,
      "before-test-run.sh"
    );
    console.log(`Running test image for proposal ${proposal.proposalName}`);
    runResult = spawnSync(
      "docker",
      [
        "run",
        "--env",
        `MESSAGE_FILE_PATH=${containerFilePath}`,
        "--mount",
        `source=${messageFilePath},target=${containerFilePath},type=bind`,
        ...removeContainerOnExit ? ["--rm"] : [],
        ...propagateSlogfile(process.env),
        ...extraDockerArgs,
        imageName
      ],
      { stdio: "inherit" }
    );
    executeHostScriptIfPresent(
      {
        MESSAGE_FILE_PATH: messageFilePath
      },
      proposal,
      "after-test-run.sh"
    );
  } finally {
    removeTempFileCallback();
  }
  if (runResult.status !== 0) {
    console.error(
      `Run of ${imageName} failed with exit code ${runResult.status}`
    );
    throw new Error(`Run of ${imageName} failed`);
  }
};
var debugTestImage = (proposal) => {
  const { name } = imageNameForProposal(proposal, "test");
  console.log(
    `
  Starting chain of test image for proposal ${proposal.proposalName}

  To get an interactive shell in the container, use an IDE feature like "Attach Shell" or this command:'

    docker exec -ti $(docker ps -q -f ancestor=${name}) bash

  And within that shell:
    cd /usr/src/proposals/${proposal.path} && ./test.sh

  To edit files you can use terminal tools like vim, or mount the container in your IDE.
  In VS Code the command is:
    Dev Containers: Attach to Running Container...
  `
  );
  return runTestImage({
    extraDockerArgs: [
      "--entrypoint",
      "/usr/src/upgrade-test-scripts/start_agd.sh",
      "--interactive",
      "--publish",
      "1317:1317",
      "--publish",
      "9090:9090",
      "--publish",
      "26657:26657",
      "--tty"
    ],
    proposal,
    removeContainerOnExit: false
  });
};

// src/cli/cli.ts
var { positionals, values } = parseArgs({
  options: {
    match: { short: "m", type: "string" },
    dry: { type: "boolean" },
    debug: { type: "boolean" }
  },
  allowPositionals: true
});
var root = path4.resolve(".");
var buildConfig = readBuildConfig(root);
var allProposals = readProposals(root);
var { match } = values;
var proposals = match ? allProposals.filter((p) => p.path.includes(match)) : allProposals;
var [cmd] = positionals;
var USAGE = `USAGE:
prepare-build   - generate Docker build configs

build           - build the synthetic-chain "use" images
  [--dry]       - print the config without building images

test            - build the "test" images and run them
                  respecting any SLOGFILE environment variable
                  https://github.com/Agoric/agoric-sdk/blob/master/docs/env.md#slogfile
  [-m <name>]   - target a particular proposal by substring match
    [--debug]   - run containers with interactive TTY and port mapping
  [--dry]       - print the config without building images

doctor          - diagnostics and quick fixes
`;
var prepareDockerBuild = () => {
  const cliPath = new URL(import.meta.url).pathname;
  const publicDir = path4.resolve(cliPath, "..", "..");
  execSync3(`cp -r ${path4.resolve(publicDir, "docker-bake.hcl")} .`);
  writeDockerfile(allProposals, buildConfig.fromTag);
  writeBakefileProposals(allProposals, buildConfig.platforms);
  execSync3(`cp -r ${path4.resolve(publicDir, "upgrade-test-scripts")} .`);
  buildProposalSubmissions(proposals);
  execSync3(
    "find upgrade-test-scripts -type f -exec touch -t 197001010000 {} +"
  );
};
switch (cmd) {
  case "prepare-build":
    prepareDockerBuild();
    break;
  case "build": {
    prepareDockerBuild();
    break;
  }
  case "test":
    prepareDockerBuild();
    if (values.debug) {
      assert3(match, "--debug requires -m");
      assert3(proposals.length > 0, "no proposals match");
      assert3(proposals.length === 1, "too many proposals match");
      const proposal = proposals[0];
      console.log(chalk.yellow.bold(`Debugging ${proposal.proposalName}`));
      bakeTarget(imageNameForProposal(proposal, "test").target, values.dry);
      debugTestImage(proposal);
    } else {
      for (const proposal of proposals) {
        console.log(chalk.cyan.bold(`Testing ${proposal.proposalName}`));
        const image = imageNameForProposal(proposal, "test");
        bakeTarget(image.target, values.dry);
        runTestImage({ proposal });
        execSync3("docker system df", { stdio: "inherit" });
        execSync3(`docker rmi ${image.name}`, { stdio: "inherit" });
        execSync3("docker system df", { stdio: "inherit" });
      }
    }
    break;
  case "doctor":
    runDoctor(allProposals);
    break;
  default:
    console.log(USAGE);
}
//# sourceMappingURL=cli.js.map